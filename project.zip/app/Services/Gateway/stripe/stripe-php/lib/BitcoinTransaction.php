<?php

namespace StripeJS;

/**
 * Class BitcoinTransaction
 *
 * @package StripeJS
 */
class BitcoinTransaction extends ApiResource
{

}
