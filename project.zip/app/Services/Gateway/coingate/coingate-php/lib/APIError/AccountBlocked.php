<?php

namespace CoinGate\APIError;

# HTTP Status 401
class AccountBlocked extends Unauthorized
{
}
